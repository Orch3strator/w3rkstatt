#!/bin/bash
sudo su - ctmem -c "/usr/bin/python3 /opt/ctm/ctm_alerts.py $*"